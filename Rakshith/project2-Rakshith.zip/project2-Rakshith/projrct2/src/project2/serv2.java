package project2;
 
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
 
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
 
/**
* Servlet implementation class serv2
*/
@WebServlet("/serv2")
public class serv2 extends HttpServlet {
                private static final long serialVersionUID = 1L;
      
    /**
     * @see HttpServlet#HttpServlet()
     */
    public serv2() {
        super();
        // TODO Auto-generated constructor stub
    }
 
                /**
                * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
                */
                protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                                PrintWriter out=response.getWriter();
                                response.setContentType("text/html");
                               
                                String op=request.getParameter("nm");
                                int opt=Integer.parseInt(op);
                                Configuration cfg=new Configuration();
                                cfg.configure("hibernate.cfg.xml");
                               
                                SessionFactory sf=cfg.buildSessionFactory();
                                org.hibernate.Session s=sf.openSession();
                                                               
                                //s.setId(Integer.parseInt(id));
                                Transaction tx=s.beginTransaction();
                               
                                if(opt>0)
                                {
                                                String hql = "FROM rak E WHERE E.id = '"+opt+"'";
                                                //String hql="from student order by id";
                                    Query query=s.createQuery(hql);
                                                List<rak> list=query.list();
 
                                                out.println("<center>");
                                                out.print("<table border=1>");
                                                for(rak d:list)
                                                {
                                                               
                                                                out.print("          Your Detalis are            ");
                                                                out.println("<tr><td>"+d.getName()+"</td><td>"+d.getId()+"</td><td>"+"</td><td>"+d.getCity()+"</td><td>"+d.getGender()+"</td><td>"+d.getMark()+"</td><td>"+d.getBlood()+"</td></tr>");
                                                               
                                                }
                                                out.println("</table>");
                                                out.println("</center>");
                                }
                                else
                                {
                                                out.println("Record not found");
                                }
                                tx.commit();
                                s.close();
                }
 
               
 
                /**
                * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
                */
                protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                                // TODO Auto-generated method stub
                                doGet(request, response);
                }
}