package project2;
 
import java.io.IOException;
import java.io.PrintWriter;
 
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
 
/**
* Servlet implementation class servlet
*/
@WebServlet("/servlet")
public class servlet extends HttpServlet {
                private static final long serialVersionUID = 1L;
      
    /**
     * @see HttpServlet#HttpServlet()
     */
    public servlet() {
        super();
        // TODO Auto-generated constructor stub
    }
 
                /**
                * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
                */
                protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                                response.setContentType("text/html");
                                PrintWriter out=response.getWriter();
                               
                                String id=request.getParameter("id");
                                String name=request.getParameter("nm");
                                String city=request.getParameter("city");
                                String Gender=request.getParameter("gn");
                                String blood=request.getParameter("blood");
                                String mark=request.getParameter("mark");
                               
                                int Id=Integer.parseInt(id);
                                int MARK=Integer.parseInt(mark);
                               
                                                rak st=new rak();
                               
                               
                                Configuration cfg=new Configuration();
                                cfg.configure("hibernate.cfg.xml").configure();
                               
                                SessionFactory sf=cfg.buildSessionFactory();
                                org.hibernate.Session s=sf.openSession();
                               
                               
                                Transaction tx=s.beginTransaction();
                                st.setBlood(blood);
                                st.setId(Id);
                                st.setName(name);
                                st.setCity(city);
                                st.setGender(Gender);
                                st.setMark(MARK);
                               
                                s.save(st);
                                tx.commit();
                                s.close();
                                sf.close();

                                                 
                }

                /**
                * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
                */
                protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                                // TODO Auto-generated method stub
                                doGet(request, response);
                }
}