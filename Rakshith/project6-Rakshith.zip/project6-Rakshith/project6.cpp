#include<iostream>
#include<list>
using namespace std;
int main()
{
    list<string>l;
    l.push_back("CAR");
    l.push_back("bike");
    l.push_back("jeep");
    list<string>::iterator it=l.begin();
    int ch;
    cout<<"1.add element\n2.delete the element\n3.show the list\n4.exit"<<endl;

   while(ch!=4)
    {
        cin>>ch;
    string item;
        switch(ch)
        {
        case 1:
            cout<<"enter the item"<<endl;
            cin>>item;
            l.push_back(item);

        break;
        case 2:
            cout<<"enter the item to delete"<<endl;
            cin>>item;
            l.remove(item);

        break;
        case 3:
        for(it=l.begin();it!=l.end();it++)
        {
        cout<<*it<<endl;
        }
        break;
        //case 4:exit(4);
        default:
            break;
       }

       cout<<"Enter choice again :";
    }


}
