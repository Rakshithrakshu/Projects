package project10;

public class student {
	 String name;
	 int age;
	 String city;

	public student(String name,int age,String city)
	{
		this.name=name;
		this.age=age;
		this.city=city;
		
			
	}
	public String show()
	{
		return name+" "+age+" "+city;	
		
	}
	
}
