package com.pro;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Hello {

	@RequestMapping("/Add")
	public ModelAndView Add(HttpServletRequest request,HttpServletResponse response)
	{
		String i=request.getParameter("t1");
		String j=request.getParameter("t2");
		String k=request.getParameter("t3");
		
		ModelAndView mv=new ModelAndView();
		if(!j.equals(k))
		{
		mv.setViewName("display.jsp");
		mv.addObject("su","password mismatch");
		}
		else
		{
			mv.setViewName("dis.jsp");
			mv.addObject("sum","welcome to homepage");
		}
		return mv;
		
	}
}
