package com.pro;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class showctrl
 */
@WebServlet("/showctrl")
public class showctrl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public showctrl() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		Connection cn;
		Statement smt;
		ResultSet rs=null;
		try
		{
	
			
			Class.forName("oracle.jdbc.driver.OracleDriver");			
			cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system", "rakshith");
			smt=cn.createStatement();
	
			
			rs=smt.executeQuery("select * from user1");
			
			out.println("<center>");
			out.print("<table border=1>");
			while(rs.next())
			{
				//out.println(+" "+);
				out.println("<tr><td>"+rs.getString("name")+"</td><td>"+rs.getInt("id")+"</td></tr>");
				
			}
			out.println("</table>");
			out.println("</center>");
			smt.close();
			
			cn.close();
		}
		catch(Exception e)
		{
			System.out.println("hi"+e);
		}	

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
