package program;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;





@Path("/book")
public class book {

    @GET
@Path("/add/{name}/{age}")
public String getdate(@PathParam("name") String name,@PathParam("age") int age)
{
                    Connection cn;
                    Statement smt;
                    
                    
                    try
                    {
    
                                    
                                    Class.forName("oracle.jdbc.driver.OracleDriver");                                             
                                    cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system", "rakshith");
                                    smt=cn.createStatement();
                                    
                                    String insert="insert into student94 values('"+name+"','"+age+"')";
                                    smt.executeUpdate(insert);
                    
                                    smt.close();
                                    cn.close();
                                    
                    }
                    catch(Exception e)
                    {
                                    System.out.println("hi"+e);
                    }              
                    
                    return "data saved in database";
}
    @GET
    @Path("/delete/{name}")
    public String delete(@PathParam("name") String name)
    {
                    
                    Connection cn;
                    Statement smt;
                    try {
                                    
                                    Class.forName("oracle.jdbc.driver.OracleDriver");                                             
                                    cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system", "rakshith");
                                    smt=cn.createStatement();
                                    
                                    
                                    String del="delete from student94 where name='"+name+"'";
                                    smt.executeUpdate(del);
                                    
                                    smt.close();
                                    cn.close();
                                    
                    } catch (Exception e)
                    {
                                    System.out.println("hi"+e);
                    }
                    
                    return "Data deleted form database";
                    
    }
    
    @GET
@Path("/update/{name}/{age}")
public String getdateupdate(@PathParam("name") String name,@PathParam("age") int age)
{
                    Connection cn;
                    Statement smt;
                    
                    
                    try
                    {
    
                                    
                                    Class.forName("oracle.jdbc.driver.OracleDriver");                                             
                                    cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system", "rakshith");
                                    smt=cn.createStatement();
                                    
                                    String insert="update student94 set age='"+age+"' where name='"+name+"'";
                                    smt.executeUpdate(insert);
                    
                                    smt.close();
                                    cn.close();
                                    
                    }
                    catch(Exception e)
                    {
                                    System.out.println("hi"+e);
                    }              
                    
                    return "data update in database";
}
    
    @GET
    @Path("/show")
    public String show()
    {
                    
                    Connection cn;
                    Statement smt;
                    ResultSet rs=null;
                    try {
                                    
                                    Class.forName("oracle.jdbc.driver.OracleDriver");                                             
                                    cn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system", "mustafabliss");
                                    smt=cn.createStatement();
                                    
                                    
                                    rs=smt.executeQuery("select * from student94");
                                    
                                    while(rs.next())
                                    {
    
                                                    return rs.getString("name")+" "+rs.getInt("age");
                                                    
                                    }
    
                                    smt.close();
                                    
                                    cn.close();
                                    
                    } catch (Exception e)
                    {
                                    System.out.println("hi"+e);
                    }
                    
                    return null;
                    
                    
    }
    
    
}
